﻿namespace Accounting_Application_System.Reports {
    
    
    public partial class ds_acctg {
        partial class subctrDataTable
        {
        }
    }
}
